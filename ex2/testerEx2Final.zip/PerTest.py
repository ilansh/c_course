import os
print 'check28:\n'
os.system("Perceptron dataSet.in.1 my_scSep1")
os.system("diff my_scSep1 separators.perc-output.map-input.1")
os.system("rm -f my_scSep1")
print 'check29:\n'
os.system("Perceptron dataSet.in.4 my_scSep4")
os.system("diff my_scSep4 separators.perc-output.map-input.4")
os.system("rm -f my_scSep4")
print 'check30:\n'
os.system("Perceptron dataSet.in.9 my_scSep9")
os.system("diff my_scSep9 separators.perc-output.map-input.9")
os.system("rm -f my_scSep9")
print 'check31:\n'
print 'check32:\n'
os.system("Perceptron noFile noFile2 > my_noFile")
os.system("diff NoResponsibility_noFilePer my_noFile")
os.system("rm -f my_noFile")
print 'check33:\n'
os.system("Perceptron arg1 > my_errArgs4")
os.system("diff NoResponsibility_errArgsSep my_errArgs4")
os.system("rm -f my_errArgs4")
print 'check34:\n'
os.system("Perceptron arg1 arg2 arg3 > my_errArgs5")
os.system("diff NoResponsibility_errArgsSep my_errArgs5")
os.system("rm -f my_errArgs5")
print 'check35:\n'
os.system("Perceptron > my_errArgs6")
os.system("diff NoResponsibility_errArgsSep my_errArgs6")
os.system("rm -f my_errArgs6")
print 'check36:\n'
os.system("Perceptron pnts1 my_sep1")
os.system("diff my_sep1 NoResponsibility_sep1")
os.system("rm -f my_sep1")
print 'check37:\n'
os.system("Perceptron pnts2 my_sep2")
os.system("diff NoResponsibility_sep2 my_sep2")
os.system("rm -f my_sep2")
print 'check38:\n'
os.system("Perceptron pnts3 my_sep3")
os.system("diff NoResponsibility_sep3 my_sep3")
os.system("rm -f my_sep3")
print 'check39:\n'
os.system("Perceptron pnts4 my_sep4")
os.system("diff NoResponsibility_sep4 my_sep4")
os.system("rm -f my_sep4")
print 'check40:\n'
os.system("Perceptron pnts5 my_sep5")
os.system("diff NoResponsibility_sep5 my_sep5")
os.system("rm -f my_sep5")
print 'check41:\n'
os.system("Perceptron pnts6 my_sep6")
os.system("diff NoResponsibility_sep6 my_sep6")
os.system("rm -f my_sep6")
print 'check42:\n'
os.system("Perceptron pnts7 my_sep7")
os.system("diff NoResponsibility_sep7 my_sep7")
os.system("rm -f my_sep7")
print 'check43:\n'
os.system("Perceptron pnts8 my_sep8")
os.system("diff NoResponsibility_sep8 my_sep8")
os.system("rm -f my_sep8")
print 'check44:\n'
os.system("Perceptron pnts9 my_sep9")
os.system("diff NoResponsibility_sep9 my_sep9")
os.system("rm -f my_sep9")
print 'check45:\n'
os.system("Perceptron pnts10 my_sep10")
os.system("diff NoResponsibility_sep10 my_sep10")
os.system("rm -f my_sep10")
print 'check46:\n'
os.system("Perceptron pnts11 my_sep11")
os.system("diff NoResponsibility_sep11 my_sep11")
os.system("rm -f my_sep11")
print 'check47:\n'
os.system("Perceptron pnts12 my_sep12")
os.system("diff NoResponsibility_sep12 my_sep12")
os.system("rm -f my_sep12")
print 'check48:\n'
os.system("Perceptron pnts13 my_sep13")
os.system("diff NoResponsibility_sep13 my_sep13")
os.system("rm -f my_sep13")
print 'check49:\n'
os.system("Perceptron pnts14 my_sep14")
os.system("diff NoResponsibility_sep14 my_sep14")
os.system("rm -f my_sep14")
print 'check50:\n'
os.system("Perceptron pnts15 my_sep15")
os.system("diff NoResponsibility_sep15 my_sep15")
os.system("rm -f my_sep15")
print 'check51:\n'
os.system("Perceptron pnts16 my_sep16")
os.system("diff NoResponsibility_sep16 my_sep16")
os.system("rm -f my_sep16")
print 'check52:\n'
os.system("Perceptron pnts17 my_sep17")
os.system("diff NoResponsibility_sep17 my_sep17")
os.system("rm -f my_sep17")
print 'check53:\n'
os.system("Perceptron pnts18 my_sep18")
os.system("diff NoResponsibility_sep18 my_sep18")
os.system("rm -f my_sep18")
print 'check54:\n'
os.system("Perceptron pnts19 my_sep19")
os.system("diff NoResponsibility_sep19 my_sep19")
os.system("rm -f my_sep19")
